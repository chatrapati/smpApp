AlaSQL is based on unpaid voluntary work. Thank you for taking the time to make it better. 

Programming question?
- Please use http://stackoverflow.com/questions/ask?tags=alasql

Something not working as expected? 
- Describe the problem  
- Provide code that replicates the problem 
- We suggest to spawn a jsfiddle from http://jsfiddle.net/mtt9r7rx/

