angular.module('shopMyTools.constants', [])

    // .constant('SERVER_URL', 'http://192.168.20.68:800')

    .constant('LOGIN_URL','http://192.168.20.69:8080')

  //  .constant('SERVER_URL1','http://192.168.20.65:8000')

    //.constant('PRODUCT_CATEGORY_SERVICE', 'http://192.168.20.67:8000')

    //.constant('PRODUCT_CATEGORY_SERVICE', 'http://192.168.20.67:8000')

    //.constant('PRODUCT_DETAIL_SERVICE', 'http://192.168.20.66:8000')




    // .constant('LOGIN_URL', 'http://157.119.108.135:8005')

    .constant('SERVER_URL', 'http://157.119.108.141:80')

    .constant('SERVER_URL1', 'http://157.119.108.142:8002')

    .constant('PRODUCT_DETAIL_SERVICE', 'http://157.119.108.139:8005')
    
    .constant('PRODUCT_CATEGORY_SERVICE', 'http://157.119.108.137:80'); 